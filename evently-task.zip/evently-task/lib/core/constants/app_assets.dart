class Assets {
  static const String verticalLogo = 'assets/images/vertical logo.png';
  static const String horizontalLogo = 'assets/images/Horizontal Logo.png';

  static const String splashBottomLogo = 'assets/images/splash bottom logo.png';

  static const String onBoarding1 = 'assets/images/onboarding_1.png';
  static const String onBoarding2 = 'assets/images/onboarding_2.png';
  static const String onBoarding3 = 'assets/images/onboarding_3.png';
  static const String onBoarding4 = 'assets/images/onboarding_4.png';
}
